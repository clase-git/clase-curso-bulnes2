extract_name <- function(url){
  archivo <- basename(url)
  nombre_archivo <- str_extract_all(archivo,"[a-zA-Z]{3}-(\\d{4})---[a-zA-Z]{8}")
  nombreArchivo <- paste(nombre_archivo,".csv",sep="")
  return(nombreArchivo)
}

download_esi_data <- function(url,file_name,directory){
  directory <- paste0("./data/",file_name)
  download(url,directory)
}

read_esi_data <- function(datos){
  read.csv(datos)
}