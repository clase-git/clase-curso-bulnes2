if(!require("tidyverse")) install.packages("tidyverse")
if(!require("downloader")) install.packages("downloader")
if(!require("purrr")) install.packages("purrr")
if(!require("microbenchmark")) install.packages("microbenchmark")
#library(readr)

install.packages("readr")
install.packages("microbenchmark")
library(microbenchmark)
library(downloader)
library(purrr)
library(tidyverse)
library(data.table)

urls <- c("https://www.ine.cl/docs/default-source/encuesta-suplementaria-de-ingresos/bbdd/csv_esi/2021/esi-2021---personas.csv?sfvrsn=d03ae552_4&download=true",
          "https://www.ine.cl/docs/default-source/encuesta-suplementaria-de-ingresos/bbdd/csv_esi/2020/esi-2020---personas.csv?sfvrsn=fb1f7e0c_4&download=true",
          "https://www.ine.cl/docs/default-source/encuesta-suplementaria-de-ingresos/bbdd/csv_esi/2019/esi-2019---personas.csv?sfvrsn=9eb52870_8&download=true",
          "https://www.ine.cl/docs/default-source/encuesta-suplementaria-de-ingresos/bbdd/csv_esi/2018/esi-2018---personas.csv?sfvrsn=a5de2b27_6&download=true",
          "https://www.ine.cl/docs/default-source/encuesta-suplementaria-de-ingresos/bbdd/csv_esi/2017/esi-2017---personas.csv?sfvrsn=d556c5a1_6&download=true",
          "https://www.ine.cl/docs/default-source/encuesta-suplementaria-de-ingresos/bbdd/csv_esi/2016/esi-2016---personas.csv?sfvrsn=81beb5a_6&download=true"
)

extract_name <- function(url){
  archivo <- basename(url)
  nombre_archivo <- str_extract_all(archivo,"[a-zA-Z]{3}-(\\d{4})---[a-zA-Z]{8}")
  nombreArchivo <- paste(nombre_archivo,".csv",sep="")
  return(nombreArchivo)
}

file_names <- map(urls,extract_name)

directory <-paste("datos",sep="")
dir.create(directory)

download_esi_data <- function(url,file_names,directory){
  directory <- paste0("./datos/",file_names)
  download(url,directory)
}

map2(urls,file_names,~download_esi_data(.x,file_names = .y,directory))

esi.list <- list.files("datos/", full.names = T)

read_esi_data <- function(datos){
  read.csv(datos)
}

esi <- map(esi.list, read_esi_data)

año <- str_extract_all(file_names,"(\\d{4})") %>% unlist()
Version <- paste0("esi_",año)

esi <- map2(esi,Version,~mutate(.x,Version = .y))

#3.1

esi_df <- esi %>%  
  bind_rows() 

Tabla_1 <- esi_df %>% select(Version,idrph,id_identificacion)

#3.2

f_tabla_2 <- function(datos){
  datos %>% 
  summarise(min = min(fact_cal_esi),
            max = max(fact_cal_esi),
            media = mean(fact_cal_esi),
            mediana = median(fact_cal_esi),
            P10 = quantile(fact_cal_esi, c(0.10)),
            P90 = quantile(fact_cal_esi, c(0.90))) 
}


Tabla_2 <- map(esi,f_tabla_2)

#3.3
 
Tabla_3 <- esi_df  %>% 
  select(Version,conglomerado,estrato) %>% 
  group_by(Version,conglomerado)  %>% 
  summarise(estratos = n())

#3.4

Tabla_4 <- map(esi, function(x){
  x %>% 
    group_by(idrph) %>%  
    summarise(min = min(ing_t_p*fact_cal_esi),
              max = max(ing_t_p*fact_cal_esi),
              media = mean(ing_t_p*fact_cal_esi),
              mediana = median(ing_t_p*fact_cal_esi),
              P10 = quantile(ing_t_p*fact_cal_esi, c(0.10)),
              P90 = quantile(ing_t_p*fact_cal_esi, c(0.90)))
})

#4.1

Tabla_4.1 <- map(esi, function(x){
  x %>% 
    group_by(idrph) %>%  
    summarise(media = mean(ing_t_p*fact_cal_esi))
})

#4.2

Tabla_4.2 <- esi_df %>% 
    group_by(Version,idrph) %>%  
    summarise(media = mean(ing_t_p*fact_cal_esi))

#4.3

class(esi_df)

dt_esi <- data.table(esi) 

Tabla_4.3 <- map(esi, function(datos){
  datos %>% 
    group_by(idrph) %>%  
    data.table(mean(ing_t_p*fact_cal_esi))
})

Tabla_4.3(dt_esi)

#4.4

dt_esi[,group_by(Version,idrph),mean(ing_t_p*fact_cal_esi)]


results <- microbenchmark(
  Tabla_4.1_test = lapply(esi, Tabla_4.1),
  Tabla_4.2_test = lapply(esi, Tabla_4.2),
  times = 5)
